# Description - A program for the One Stop Insurance Company to help with calculating and entering
# new insurance policy information for its customers.

# Author - Noah Devine SD12

# Date - July 16th, 2024 - July 24th, 2024

# Define required libraries.
import datetime
import time
import sys


# Define program constants.
f = open('Const.dat', 'r')

POL_NUM = int(f.readline())
BASIC_PREM = float(f.readline())
DIS_ADD_CARS = float(f.readline())
LIA_COVERAGE = float(f.readline())
GLASS_COVERAGE = float(f.readline())
LOANER_COVERAGE = float(f.readline())
HST_RATE = float(f.readline())
PROCESS_FEE = float(f.readline())

f.close()

CUR_DATE = datetime.datetime.now()

# Define program functions.
def PhoneNew(PhoneNum):

   PhoneNumNew = "(" + PhoneNum[0:3] + ")" + PhoneNum[3:6] + "-" + PhoneNum[6:]

   return PhoneNumNew

def NewDate(DateVaule):

    FormatDates = datetime.datetime.strptime(DateVaule, "%Y-%m-%d")

    FormatDatesDsp = datetime.datetime.strftime(FormatDates, "%Y-%m-%d")

    return FormatDatesDsp

def NewNumber(Value):

    NumVal = "${:,.2f}".format(Value)

    return NumVal


# Main program starts here.

# Set up inputs with specified validations.
while True:
    CustFirstName = input("Please enter the customers first name: ").title()
    CustLastName = input("Please enter the customers last name: ").title()
    Address = input("Please enter your street address: ")
    City = input("Please enter the name of the city: ").title()

    ProvLst = ["NL", "QC", "ON", "SK", "PE", "NS", "NB", "MB", "AB", "BC", "YT", "NT", "NU"]
    while True:
        Prov = input("Enter the province (XX): ").upper()
        if Prov == "":
            print()
            print("Data entry error - province cannot be blank - reenter.")
            print()
        elif len(Prov) != 2:
            print()
            print("Data entry error - province must be a 2 digit code - reenter.")
            print()
        elif Prov not in ProvLst:
            print()
            print("Data entry error - entry is not a valid province - reenter.")
            print()
        else:
            break

    PostCode = input("Please enter the postal code (XXXXXX): ").upper()
    PhoneNum = input("Please enter the phone number (XXXXXXXXXX): ")
    CarsIns = int(input("Please enter the number of cars being insured: "))

    while True:
        ExtraLiab = input("Do you want extra liability? (Y/N): ").upper()
        if ExtraLiab == "":
            print()
            print("Data entry error - entry cannot be blank.")
            print()
        elif ExtraLiab != "Y" and ExtraLiab != "N":
            print()
            print("Data entry error - choice must be either Y or N.")
            print()
        else:
            break

    
    while True:
        GlassCover = input("Do you want glass coverage? (Y/N): ").upper()
        if ExtraLiab == "":
            print()
            print("Data entry error - entry cannot be blank.")
            print()
        elif GlassCover != "Y" and GlassCover != "N":
            print()
            print("Data entry error - choice must be either Y or N.")
            print()
        else:
            break

    
    while True:
        Loaner = input("Do you want a loaner vehicle? (Y/N): ").upper()
        if ExtraLiab == "":
            print()
            print("Data entry error - entry cannot be blank.")
            print()
        elif Loaner != "Y" and Loaner != "N":
            print()
            print("Data entry error - choice must be either Y or N.")
            print()
        else:
            break

    PayLst = ["Full", "Monthly", "Down Pay"]
    while True:
        PayOpt = input("Do you want to pay in full, monthly, or a down payment? (Full/Monthly/Down Pay): ").title()
        if PayOpt == "":
            print()
            print("Data entry error - entry cannot be blank - reenter.")
            print()
        elif PayOpt not in PayLst:
            print()
            print("Data entry error - payment option is not valid - reenter.")
            print()
        elif PayOpt == "Down Pay":
            AmoDown = float(input("Please enter the down payment amount: "))
            break
        else:
            AmoDown = 0
            break

    # Setting up lists for previous claims.
    
    PrevClaimNum = []
    PrevClaimDate = []
    PrevClaimAmo = []
   
    while True: 
        PrevNum = input("Please enter a previous claim number (XXXXX): ")
        PrevDate = input("Please enter previous claim date (YYYY-MM-DD): ")
        PrevDate = NewDate(PrevDate)
        PrevAmo = float(input("Please enter a previous claim amount: "))
        PrevAmo = NewNumber(PrevAmo)
        PrevClaimNum.append(PrevNum)
        PrevClaimDate.append(PrevDate)
        PrevClaimAmo.append(PrevAmo)

        Continue = input("Would you like to enter more data? (Y/N): ").upper()
        if Continue == "N":
            break  
    
    
# Perform required calculations.
    Discount = BASIC_PREM * DIS_ADD_CARS
    AddCarPre = (CarsIns - 1) * (BASIC_PREM - Discount)
    InsurancePre = BASIC_PREM + AddCarPre

    if ExtraLiab == "Y":
        LiabCost = LIA_COVERAGE * CarsIns
    else:
        LiabCost = 0
        

    if GlassCover == "Y":
        GlassCost = GLASS_COVERAGE * CarsIns
    else:
        GlassCost = 0
        

    if Loaner == "Y":
        LoanerCost = LOANER_COVERAGE * CarsIns
    else:
        LoanerCost = 0 
        

    TotalExtraCosts = LiabCost + GlassCost + LoanerCost

    TotalInsurancePre =  InsurancePre + TotalExtraCosts

    HST = TotalInsurancePre * HST_RATE

    TotalCost = TotalInsurancePre + HST

    if PayOpt == "Down Pay":
        TotalAfDow = TotalCost - AmoDown
        MonthlyPayment = (TotalAfDow + PROCESS_FEE) / 8
    else:
        MonthlyPayment = (TotalCost + PROCESS_FEE) / 8
        TotalAfDow = 0

    InvoiceDate = CUR_DATE

    if InvoiceDate.month == 12:
        FirstPayDate = datetime.datetime(InvoiceDate.year, + 1, 1, 1)
    else:
        FirstPayDate = datetime.datetime(InvoiceDate.year, InvoiceDate.month + 1, 1)

    
    # Display input & calculated values to the user.

    InvoiceDateDsp = InvoiceDate.strftime(("%Y-%m-%d"))
    FirstPayDateDsp = FirstPayDate.strftime(("%Y-%m-%d"))

    print()
    print(f"                        One Stop Insurance Company")
    print(f"                   For all your insurance policy needs!")
    print(f"      =============================================================")
    print(f"      Customer Name: {CustFirstName}             Policy Number:   {POL_NUM}")
    print(f"                     {CustLastName}           Phone Number:   {PhoneNew(PhoneNum)}")                             
    print(f"      =============================================================")
    print(f"      Customer Address: {Address}")
    print(f"                        {City}, {PostCode}")
    print()
    print(f"      Cars Insured:     {CarsIns:>2d}           Glass Coverage:      {GlassCover:>9s}")
    print(f"      Loaner Car:       {Loaner:>2s}           Extra Liiability:    {ExtraLiab:>9s}")
    print(f"      Payment Method:  {PayOpt:<8s}      Down Payment Amount: {NewNumber(AmoDown):>9s}")
    print(f"      =============================================================")
    print(f"      Insurance Premium:                                  {NewNumber(InsurancePre):>9s}")
    print(f"      Extra Charges:                                      {NewNumber(TotalExtraCosts):>9s}")
    print(f"      Total Insurance Premium:                            {NewNumber(TotalInsurancePre):>9s}")
    print(f"      =============================================================")
    print(f"      HST:                                                {NewNumber(HST):>9s}")
    print(f"      Total Cost:                                         {NewNumber(TotalCost):>9s}")
    print(f"      Monthly Payments (8 months):                        {NewNumber(MonthlyPayment):>9s}")
    print(f"      =============================================================")
    print(f"      Invoice Date: {InvoiceDateDsp}       First Payment Date: {FirstPayDateDsp}")
    print(f"      =============================================================")
    print(f"                             Previous Customer")
    print(f"                             Claim Information")
    print()
    print(f"      Claim #                   Claim Date                   Amount")
    print(f"      -------------------------------------------------------------")
    for PrevNum, PrevDate, PrevAmo in zip(PrevClaimNum, PrevClaimDate, PrevClaimAmo):
        print(f"      {PrevNum:>5s}                     {PrevDate:>10s}               {PrevAmo:>9s}")
    print(f"      =============================================================")

    # Write processed data to Policy.dat and then close the file.

    f = open("Policy.dat", "a") 
 
    
    f.write(f"{str(POL_NUM)}, ")
    f.write(f"{CustFirstName}, ") 
    f.write(f"{CustLastName}, ")
    f.write(f"{Address}, ")
    f.write(f"{City}, ")
    f.write(f"{Prov}, ")
    f.write(f"{PhoneNum}, ")
    f.write(f"{(PostCode)}, ")
    f.write(f"{str(CarsIns)}, ")
    f.write(f"{(ExtraLiab)}, ")
    f.write(f"{(GlassCover)}, ")
    f.write(f"{(Loaner)}, ")
    f.write(f"{(PayOpt)}, ")
    f.write(f"{str(AmoDown)}, ")
    f.write(f"{str(TotalInsurancePre)}\n")
 
    f.close()
    
    # Display a blinking message to show the user that the data is being saved.

    print()
 
    Message = "Saving Policy Information ..."
    for _ in range(5):  
        print(Message, end='\r')
        time.sleep(.3)  
        sys.stdout.write('\033[2K\r')  
        time.sleep(.3)
 
    print()

    print()
    print("Insurance policy information has been successfully saved to Policy.dat ...")
    print()

    # End of program housekeeping duties.
    
    POL_NUM += 1

    f = open("Const.dat", "w")

    f.write(f"{POL_NUM}\n")
    f.write(f"{str(BASIC_PREM)}\n")
    f.write(f"{str(DIS_ADD_CARS)}\n")
    f.write(f"{str(LIA_COVERAGE)}\n")
    f.write(f"{str(GLASS_COVERAGE)}\n")
    f.write(f"{str(LOANER_COVERAGE)}\n")
    f.write(f"{str(HST_RATE)}\n")
    f.write(f"{str(PROCESS_FEE)}\n")

    f.close()
    

    Continue = input("Do you want to process another insurance policy (Y/N): ").upper()
    if Continue == "N":
        break


    
    

    



    




    



