// Motel Customer Object with arrays & sub-objects.

const motelCustomer = {
name: 'Ryan Reynolds',
birthDate: '1998-03-09',
gender: 'male',
roomPreferences: ['king size bed', 'pet friendly'],
paymentMethod: 'cash',
mailingAddress: {
city: 'Gander',
street: '123 Deadpool Lane',
province: 'NL'
},
phoneNumber: '709-689-0987',
hisStay: {
checkInDate: '2024-07-20',
checkOutDate: '2024-07-22'
}}

// Calculate the motel customers age and display it in the console log.
// Change the birthDate under motelCustomer to see how my if statement works

const birthDateRyan = new Date(motelCustomer.birthDate);
const currDate = new Date();

if (currDate.getMonth() >= birthDateRyan.getMonth() && currDate.getDate() >= birthDateRyan.getDate())
{const age = currDate.getFullYear() - birthDateRyan.getFullYear()
console.log(`${motelCustomer.name} is ${age} years old and getting older!`)}
else{
const age = currDate.getFullYear() - birthDateRyan.getFullYear() -1
console.log(`${motelCustomer.name} is ${age} years old and getting older!`)}

// Calculate the length of Ryan Reynolds stay at the motel and display results in the console log

const checkInDateNew = new Date(motelCustomer.hisStay.checkInDate);
const checkOutDateNew = new Date(motelCustomer.hisStay.checkOutDate);

const lengthStay = (checkOutDateNew - checkInDateNew) / (1000 * 60 * 60 * 24);

console.log(`${motelCustomer.name} stayed at the fancy motel for ${lengthStay} days`)

// Write the description to the html page & console log

const motelCustDescription = (`${motelCustomer.name} is a handsome young ${motelCustomer.gender} who once stayed in our motel.
He was born on ${motelCustomer.birthDate} and checked in on ${motelCustomer.hisStay.checkInDate} and checked out on ${motelCustomer.hisStay.checkOutDate}. 
We shouldn\'t give this out, but his mailing address on file is ${motelCustomer.mailingAddress.street}, ${motelCustomer.mailingAddress.city} ${motelCustomer.mailingAddress.province}.
When he booked with us, he requsted that his room have a ${motelCustomer.roomPreferences[0]} and that the room was also ${motelCustomer.roomPreferences[1]}.
${motelCustomer.name} also lost his wallet at our motel and requested that you call ${motelCustomer.phoneNumber} if you happen to find it.
He will also give you a ${motelCustomer.paymentMethod} reward if you happen to find it.`)

document.write(motelCustDescription);
console.log(motelCustDescription);
